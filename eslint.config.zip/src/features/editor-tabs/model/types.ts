export type Tab = {
    id: string;
    name: string;
    content: string;
    isActive: boolean;
  };
  